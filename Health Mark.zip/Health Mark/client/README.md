TEAM - 09 Individual Contribution Document
Project Name: HEALTH MARK

Team Members :

NAVEEN KUMAR KALYANAM,SAI NIKHIL MATTAPALLI,TANMAYEE CHANDANAM,DIVYA SATYA PRADHANYA VUNDAVILLI,MANIDEEP MYLAVARAPU

Project Details :

One Platform for doctors, patients and medical stores

Execution steps for Front end: Open terminal and run the following commands.

cd client
npm install --legacy-peer-deps
npm run dev

Execution steps for backend:

cd server
npm i
npm start 

I will start and provide a vite link when we move cursor to link it will give follow link when we click on follow link the website or application start.

Here we have users:

USER/CUSTOMER/PATIENT
VENDOR
DOCTOR
ADMIN

sample payment card details im giving for trial purpose:

Visa	4242424242424242	Any 3 digits	Any future date
Mastercard	5555555555554444	Any 3 digits	Any future date