import React from 'react'

const UserProfile = () => {
  document.title = 'Health Mark | User Profile';
  return (
    <div>UserProfile</div>
  )
}

export default UserProfile