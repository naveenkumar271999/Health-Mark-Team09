import AppRouter from "../routes/AppRouter";


const App = () => <AppRouter />

export default App;
