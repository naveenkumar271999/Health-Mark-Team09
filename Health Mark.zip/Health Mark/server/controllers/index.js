const userController = require('./userController');
const categoryController = require('./categoryController');
const cartController = require('./cartController');
module.exports = {
    userController,
    categoryController,
    cartController,
}